package VMAPS_POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
	private static WebDriver d;
	public Login(WebDriver d) { 
        this.d = d; 
        PageFactory.initElements(d,this);
    }
	
	
	
	@FindBy(xpath = "//input[@id='login-email']")
	private WebElement usern;

	public WebElement getuname () {
		return usern;
		
	}

	@FindBy(xpath = "//input[@id='login-password']")
	private WebElement password;

	public WebElement getpass1() {
		return password;
	}
	    
	@FindBy(xpath = "//span[@id='login-submit-text']")
	private WebElement signin1;

	public WebElement getsigingin() {
		return signin1;
	}
	
	@FindBy(xpath = "//button[@id='profile']")
	private WebElement signout1;

	public WebElement getsingout1() {
		return signout1;
	}
	@FindBy(xpath = "//ul[@class='dropdown-menu dropdown-menu-end show']")
	private WebElement signout2;

	public WebElement getsigninout2() {
		return signout2;
	}
}
